--- 
title: "MATH 3070 R Lecture Notes"
author: "Curtis Miller"
date: '2018-08-17'
output:
  bookdown::pdf_book:
    includes:
      in_header: preamble.tex
    number_sections: false
  bookdown::gitbook:
    number_sections: false
description: MATH 3070 Lecture Notes
documentclass: book
---

# Preface {-}

These lecture notes were written by me to accompany John Verzani's [*Using R  for Introductory Statistics (2nd ed.)*](https://www.crcpress.com/Using-R-for-Introductory-Statistics-Second-Edition/Verzani/p/book/9781466590731), to be delivered in lectures teaching students how to program with R in the programming lab accompanying a lecture section focusing on the statistical methods themselves. No knowledge of programming is assumed; my objective was to teach basic R programming well enough to use R for statistical analyses.

These notes are not intended to stand alone; I like Verzani's book and I believe that these notes should supplement it, not replace it. For those taking the programming lab for the University of Utah's Mathematics Department statistics courses, I would *insist* on reading Verzani's book in addition to these lecture notes. However, these notes could serve as a light weight introduction to R and statistical programming.

These lecture notes were adapted from lecture notes written for an eight-week intensive course covering the same topics that I also wrote. Most of the notes are an exact duplication, but in order to accomodate the instructors of the lecture sections (none of which I was teaching at the time) I added and rearranged lectures to slow down the lab's pace.

Lectures 1 through 4 cover R basics. Lectures 5 and 6 cover plotting. Lectures 7 and 8 cover multivariate analysis (lightly; this is a topic covered in greater depth in another course). Lecture 9 discusses probability models in R. Lecture 10 dives into the ["tidyverse"](https://www.tidyverse.org/), discussing **dplyr**, **magrittr**, and **reshape2** for data manipulation (this does *not* correspond to material in Verzani's book). Lecture 11 discusses computer-intensive methods for hypothesis testing (based on resampling methods). Lecture 12 discusses bootstrapping and Bayesian statistics (*very light* Bayesian statistics). Chapter 13 discusses confidence intervals, and Chapter 14 covers hypothesis testing.

I hope that you find these notes useful, and wish you the best of luck.

Curtis Miller
