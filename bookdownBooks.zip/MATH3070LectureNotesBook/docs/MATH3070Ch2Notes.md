---
title: "Chapter 2: Probability"
subtitle: "Textbook Notes"
author: "Curtis Miller"
date: "2018-08-17"
output:
  tufte::tufte_handout:
    citation_package: natbib
    latex_engine: pdflatex
    includes:
      in_header: MATH3070NotesPreamble.sty
  tufte::tufte_html: 
  tufte::tufte_book:
    citation_package: natbib
    latex_engine: pdflatex
bibliography: MATH3070Citations.bib
link-citations: yes
---



# Chapter 2: Probability

## Introduction

\newthought{Next we focus on} probability. **Probability** is the mathematical study of randomness and uncertain outcomes. The subject may be as old as calculus. Modern statistics is based on probability theory, often estimating parameters that arise from a probability model. The subject is big and fascinating and sometimes shockingly counterintuitive. In this chapter we introduce basic ideas in probability theory and the theory of counting and combinatorics.

## Section 1: Sample Spaces and Events

An **experiment** is an activity or process with an uncertain outcome. Example experiments include:

* Flipping a coin
* Flipping a coin until the coin lands heads-up
* Rolling a six-sided die
* Rolling two six-sided dice
* The time in the morning you wake up

When we have an experiment we need to describe the **sample space**, $\mathcal{S}$^[Another extremely common notation for the sample space is $\Omega$.], which is the set of all possible outcomes of the experiment. A **set** is loosely defined as a collection of objects.^[This definition cannot be rigorous because it leads to paradoxes. Bertrand Russell was able to find sets that, while legally defined this way, cannot logically exist. Examples include "a set of all sets" and "a set of sets that do not have themselves as members." Axiomatic set theory defines sets in a way that avoids paradoxes but the theory is more complicated than necessary for typical use; the "naive" definition is usually fine.] **Events** are subsets of the sample space^[The sample space is a subset of the sample space and thus is an event, which can be thought of as the event that anything happens.], defining possible outcomes of an experiment. The **empty set** or **null event**, $\varnothing$, is a set with no members; it can be thought of as the event that nothing happens.

---

\newpage

### Example 1

Define a sample space for the experiment of flipping a coin. List all possible events for this experiment.

\vspace{2.5in}

### Example 2

Define a sample space for the experiment of rolling a six-sided die. List three events based on this sample space.

\vspace{2in}

### Example 3

Define a sample space describing the experiment of flipping a coin until it lands heads-up. List five events for this sample space.

\newpage

### Example 4

Define a sample space describing the experiment of rolling two six-sided die simultaneoulsy. List three events from this sample space.

\vspace{4in}

### Example 5

Define a sample space describing the experiment of waking up in the morning at a particular time, where the time you wake up at (thought of as a real number) is the outcome of interest. List three events from this sample space.

\vspace{4in}

---

Events can be manipulated in ways to "create" new events. Let $A$ and $B$ be events. The **complement** of $A$, denoted $A'$^[Other common notation includes $\overline{A}$ and $A^c$.] is the set of outcomes of $\mathcal{S}$ not in $A$, which in words is the event "not $A$". The **union** of two sets, $A \cup B$, is the set that combines the contents of the sets $A$ and $B$, which in words means "$A$ or $B$".^[Sets only ever include one copy of each element, so $\{H, H\} = \{H\}$. This implies that if there is a copy of $x$ in both $A$ and $B$, there will not be two copies of $x$ in $A \cup B$; there is only one copy.] The **intersection** of two sets, $A \cap B$, is the set that only includes objects that appear in both $A$ and $B$, which in words means "$A$ and $B$".

Two sets are **disjoint** if they have no elements in common. In that case, $A \cap B = \varnothing$.

An intuitive approach to set theory is the use of **Venn diagrams**, where set-theoretic relations are illustrated by depicting objects as points on a plane and denoting set membership with enclosed regions. Below are Venn diagrams illustrating the relations between two sets just described.

\newpage

---

### Example 6

Use a Venn diagram to illustrate $(A \cup B)' \cup (A \cap B)$.

\vspace{2.5in}

### Example 7

Consider three sets $A$, $B$, and $C$. Illustrate:

1. $A \cup B \cup C$\vspace{3in}
2. $A \cap B \cap C$\vspace{3in}
3. $(A \cap B) \cup (A \cap C) \cup (B \cap C)$\vspace{3in}

### Example 8

Describe the intersection, complement, and union of events described in Examples 1 through 5

\vspace{6in}

---

## Section 2: Axioms, Interpretations, and Properties of Probability

In probability our objective is to assign numbers to events describing how likely that event is to occur. Thus, a **probability measure**, $\mathbbm{P}$, is a function taking events as inputs and returning numbers between 0 and 1, and satisfies the following three axioms:

1. $\Prob{A} \geq 0$
2. $\Prob{\mathcal{S}} = 1$
3. If $A_1, A_2, ...$ is a sequence of disjoint events (so that for any $i \neq j$, $A_i \cap A_j = \varnothing$), then $\Prob{A_1 \cup A_2 \cup ...} = \Prob{\bigcup_{i = 1}^\infty A_i} = \sum_{i = 1}^\infty \Prob{A_i}$^[You may understand this in the more common situation where if $A \cap B = \varnothing$, $\Prob{A \cup B} = \Prob{A} + \Prob{B}$.]

From these, we get all other intuitive relations in probability.

\begin{proposition}
$\Prob{\varnothing} = 0$
\end{proposition}

\vspace{4in}

\begin{proposition}
$\Prob{A'} = 1 - \Prob{A}$
\end{proposition}

\vspace{4in}

\begin{proposition}
$\Prob{A} \leq 1$ for any event $A$.
\end{proposition}

\vspace{4in}

\begin{proposition}
$\Prob{A \cup B} = \Prob{A} + \Prob{B} - \Prob{A \cap B}$ for any events $A$ and $B$.
\end{proposition}

\vspace{6in}

\begin{proposition}
For any events $A$, $B$, and $C$,

\begin{align*}
\Prob{A \cup B \cup C} &= \Prob{A} + \Prob{B} + \Prob{C} \\
& - \Prob{A \cap B} - \Prob{A \cap C} - \Prob{B \cap C} \\
& + \Prob{A \cap B \cap C}
\end{align*}
\end{proposition}

---

### Example 9

Reconsider the experiment of flipping a coin, and assume that the coin is equally likely to land with each face facing up. Assign probabilities to all outcomes in the sample space.

\vspace{2in}

### Example 10

Do the same as Example 9, but when rolling a single dice.

\vspace{2in}

### Example 11

The dice from Example 10 has been altered with weights. Now, the probability of the dice rolling a 6 is twice as likely as rolling a 1, while all other sides still have the same probability of appearing as before. What is the new probability model?

\vspace{2.5in}

### Example 12

Reconsider the experiment of rolling two six-sided die. It's reasonable to assume that each outcome in $\mathcal{S}$ is equally likely. What, then, is the probability of each outcome in $\mathcal{S}$?

\vspace{0.5in}

Use this model to find the probability of event $E$, where:

1. $E = \{\text{At least one dice is a 6}\}$\vspace{3in}
2. $E = \{\text{The sum of the pips showing on the two die is 5}\}$\vspace{3in}
3. $E = \{\text{The maximum of the two numbers showing on the die is greater than 2}\}$\vspace{2in}

### Example 13

Reconsider the experiment of flipping a coin until $H$ is seen. What is one way to assign probabilities to all outcomes of this experiment so that we have a legal probability model? Justify your answer.

\vspace{2in}

With this model, answer the following questions:

1. What is the probability the number of flips needed to see the first $H$ exceeds 4?\vspace{1in}
2. What is the probability the number of flips until the experiment ends is between 3 and 20?\vspace{1in}
3. What is the probability that an even number of flips is seen before the experiment ends?\vspace{1in}

### Example 14

In a small town, 20% of the population is considered "wealthy", 30% of the population identifies as "black", and 5% of the population is "wealthy" and "black". Select a random individual from this population (everyone equally likely to be selected). What is the probability this individual is "wealthy" and "not black"?\vspace{1.5in}

What is the probability this individual is neither wealthy nor black?\vspace{1.5in}

### Example 15

A bag contains balls and blocks. 30% of the bag's contents are balls. An object is either red or blue, and 40% of the objects are red. An object is made of either wood or plastic, and 65% of the objects are wooden. 10% of the objects are wooden balls, 5% of the objects are red balls, and 20% of the objects are red and plastic. 2% of the objects are red plastic blocks.

Reach into the bag and pick out an object at random, each object equally likely to be selected.

1. What is the probability the object selected is a ball, red, or wooden?\vspace{3in}
2. What is the probability the object is a red wooden ball?\vspace{3in}
3. What is the probability that the object is a blue plastic block?\vspace{3in}

\newpage

---

How do we interpret probabilies? The **frequentist interpretation of probability**^[This interpretation isn't the only one. Any interpretation limits the kind of questions you can obtain probabilities for. In this case, the frequentist interpretation suggests that probabilities can be assigned only to repeatable experiments. While the frequentist interpretation is simple it can lead to convoluted language as we avoid referencing probabilities for nonrepeatable circumstances. The convoluted interpretation of confidence intervals, for example, is due to this interpretation of what a probability means. It turns out though that the rigorous mathematical theory of probability, which is based on measure theory and real analysis, does not care about the "interpretation" of a probability, so all the mathematics remain the same no matter what interpretation we choose.] interprets probabilities as the long-run relative frequency as we repeat an experiment many times. For example, if we were to flip a fair coin many times, the proportion of times the coin lands heads up would approach $\frac{1}{2}$.

The chart below illustrates this idea.

\newpage


```r
set.seed(11618)    # Choosing a number to set the seed, for replicability
n <- 15
flips <- rbinom(n, 1, 0.5)
heads <- cumsum(flips == 1)
plot(1:n, heads/(1:n), type = "l", ylim = c(0, 1), xlab = "Flips",
     ylab = "Proportion")
abline(h = 0.5, col = "blue", lty = "dashed")
```


\includegraphics{MATH3070Ch2Notes_files/figure-latex/unnamed-chunk-1-1} 


```r
n <- 50
flips <- rbinom(n, 1, 0.5)
heads <- cumsum(flips == 1)
plot(1:n, heads/(1:n), type = "l", ylim = c(0, 1), xlab = "Flips",
     ylab = "Proportion")
abline(h = 0.5, col = "blue", lty = "dashed")
```


\includegraphics{MATH3070Ch2Notes_files/figure-latex/unnamed-chunk-2-1} 


```r
n <- 500
flips <- rbinom(n, 1, 0.5)
heads <- cumsum(flips == 1)
plot(1:n, heads/(1:n), type = "l", ylim = c(0, 1), xlab = "Flips",
     ylab = "Proportion")
abline(h = 0.5, col = "blue", lty = "dashed")
```


\includegraphics{MATH3070Ch2Notes_files/figure-latex/unnamed-chunk-3-1} 

## Section 3: Counting Techniques

Consider a burger shop, Bob's Burgers, that offers three types of bread: white, rye, and sourdough. A burger can come with or without cheese. How many burgers are possible?

We first answer this question using a **tree diagram**:

\vspace{3in}

Or we can answer using the **product rule**:

\begin{proposition}
If there are $n_1$ possibilities for choice 1, $n_2$ possibilities for choice 2, ..., $n_k$ possibilities for choice $k$, then there are $n_1 n_2 ... n_k = \prod_{i = 1}^k n_i$ total possible combinations.
\end{proposition}

Using the product rule:

\vspace{0.5in}

---

### Example 16

The sandwich shop Deluxe Deli offers four bread options (white, sourdough, whole wheat and rye), five meat options (turkey, ham, beef, chicken, no meat), six cheese options (cheddar, white cheddar, swiss, American, pepperjack, no cheese), with or whithout lettuce, with or without tomatoes, with or without bacon, with or without mayonaise, and with or without mustard. How many sandwiches are possible?

\vspace{2in}

---

Suppose that out of $n$ possibilities we will be choosing $k$. We have two essential questions to answer:

1. Do we choose with or without replacement?
2. Does order matter?

Depending on our answer our question has different solutions, summarized below:

\vspace{0.5in}

\begin{tabular}{r|cc}
 & With replacement & Without replacement \\
 \hline
Ordered & $n^k$ & $P_{n,k} = \frac{n!}{(n - k)!}$ \\
Not ordered & ${k + n - 1 \choose n - 1}$ & ${n \choose k} = \frac{n!}{k!(n - k)!}$ \\
\end{tabular}

\vspace{0.5in}

**Justifications**

\newpage

\phantom{blablabla}

\newpage

---

### Example 17

When we roll two six-sided die, we assume each outcome is equally likely (if the dice are different colors). How many possible outcomes are there? What about for three six-sided die?

\vspace{1.5in}

### Example 18

A high school has 27 boys playing men's basketball. In basketball, there are five positions: point guard (PG), shooting guard (SG), small forward (SF), power forward (PF), and center (C). Each assignment of player to position is unique. How many teams can be formed?

\vspace{2in}

### Example 19

When playing poker, players draw five cards from a 52-card deck. Every card is distinct, but the order of the draw does not matter. How many hands are possible?

\newpage


```r
## Example 16
6^2
```

```
## [1] 36
```

```r
6^3
```

```
## [1] 216
```

```r
## Example 17
factorial(27)/factorial(27 - 5)
```

```
## [1] 9687600
```

```r
## Example 18
choose(52, 5)
```

```
## [1] 2598960
```

### Example 20

You want to choose a dozen donuts from a donut shop. There are eight different kinds of donuts. How many boxes of a dozen donuts are possible?

\newpage


```r
choose(12 + 8 - 1, 8 - 1)
```

```
## [1] 50388
```

For the next few examples, we will be using a standard^[The "standard" deck is the French deck, the most common deck in the English-speaking world. Other European countries have their own traditional decks.] 52-card deck of playing cards. In this deck, each card belongs to one of four suits: spades ($\spadesuit$), hearts ($\heartsuit$), clubs ($\clubsuit$), and diamonds ($\diamondsuit$). Each card has a face value, which is either Ace (A), King (K), Queen (Q), Jack (J), or a number between 2 and 10; there are 13 possible face values. Hearts and diamonds are colored red, while spades and clubs are colored black. The notation $8\diamondsuit$ means "eight of diamonds", $\text{K}\spadesuit$ means "king of spades", and so on.

### Example 21

A poker hand is "four of a kind" if four cards have the same face value. How many four-of-a-kind hands exist?

\vspace{3in}

### Example 22

A poker hand is "full house" of two cards have the same face value and three different cards have another common face value. How many "full house" hands exist?

\newpage


```r
## Example 20
(a1 <- 13 * 48)
```

```
## [1] 624
```

```r
## Example 21
(a2 <- 13 * choose(4, 3) * 12 * choose(4, 2))
```

```
## [1] 3744
```


### Example 23

A "flush" is a poker hand where all cards belong to the same suit. How many "flush" hands exist (including straight flush hands)?

\vspace{2in}

### Example 24

A "straight" is poker hand where the cards can be arranged in sequence: for example, $5\spadesuit 6\clubsuit 7\clubsuit 8\heartsuit 9\heartsuit$ is a straight (suit does not matter). A "straight flush" is both a straight and a flush, so it is a flush with all cards belonging to the same suit (and the best possible hand). How many straight flush hands exist? How many straight hands exist (that are *not* straight flushes)?

\newpage


```r
## Example 22
(a3 <- 4 * choose(13, 5))
```

```
## [1] 5148
```

```r
## Example 23
(a4 <- 10 * 4^5 - 4 * 10)
```

```
## [1] 10200
```


---

For finite sample spaces, there is a natural probability measure, defined below for a set $A$.

\vspace{1in}

---

### Example 25

Use the natural probability measure to compute the probability of each poker hand mentioned in Examples 21 to 24.

\newpage


```r
s <- choose(52, 5)
a1/s  # Exc. 20
```

```
## [1] 0.000240096
```

```r
a2/s  # Exc. 21
```

```
## [1] 0.001440576
```

```r
a3/s  # Exc. 22
```

```
## [1] 0.001980792
```

```r
a4/s  # Exc. 23
```

```
## [1] 0.003924647
```

---

## Section 4: Conditional Probability

Consider flipping a fair coin three times. What is the probability the same face will appear three times?

\vspace{0.5in}

Now suppose I told you that the first two flips were $HH$. What is the probability of this event now?

\vspace{0.5in}

This demonstrates the need for **conditional probability**, which is a probability of an event given the fact that another event has occured. The probability of $A$ given $B$ has occured, denoted $\Probcond{A}{B}$, is:

\vspace{0.5in}

There is an illustration for making this definition intuitive:

\vspace{1.5in}

Given a conditional probability we can also compute $\Prob{A \cap B}$:

\vspace{0.5in}

Given $\Probcond{A}{B}$, what is $\Probcond{A'}{B}$?

\vspace{0.5in}

---

### Example 26

Use the definition of conditional probability to compute the probability of the event that all three coins have the same face up when flipped given the first two flips were heads.

\vspace{0.5in}

### Example 27

Suppose that you were dealt two cards of a five-card poker hand, which are $\text{K}\heartsuit 8\heartsuit$. Given this information, what is the probability your complete hand will be a full house?

\newpage


```r
## Hands with KH 8H
(den <- choose(50, 3))
```

```
## [1] 19600
```

```r
## Full house hands with KH 8H
(num <- 2 * choose(3, 1) * choose(3, 2))
```

```
## [1] 18
```

```r
num / den
```

```
## [1] 0.0009183673
```

```r
(num/s) / (den/s)
```

```
## [1] 0.0009183673
```


### Example 28

Suppose your five-card poker hand is a flush. What is the probability it is a straight flush?

\vspace{2in}

### Example 29

Suppose your five-card poker hand is a straight. What is the probability it is a straight flush?

\vspace{2in}

### Example 30

In a certain village 20% of individuals are considered "wealthy" and 35% are considered "black". Among blacks, 60% are not considered "wealthy". If you chose a random individual from this village, what is the probability this individual is "black" and "wealthy"?

\vspace{2in}

---

A **partition** is a division of $\mathcal{S}$ into sets $A_1, ..., A_n$ such that for $i \neq j$, $A_i \cap A_j = \varnothing$, and $\bigcup_{i = 1}^n A_i = \mathcal{S}$. Below is an illustration:

\vspace{2in}

\begin{theorem}[Law of Total Probability]
Let $A_1, ..., A_n$ be a partition of $\mathcal{S}$ and $B$ be an event. Then:

$$\Prob{B} = \sum_{i = 1}^n \Probcond{B}{A_i} \Prob{A_i}$$
\end{theorem}

We can then state Bayes' Theorem^[Bayes' Theorem is also seen in the simpler form where the partition is $A$ and $A'$, in which case the statement becomes $$\Probcond{A}{B} = \frac{\Probcond{B}{A}\Prob{A}}{\Probcond{B}{A}\Prob{A} + \Probcond{B}{A'}\Prob{A'}}$$]:

\begin{theorem}[Bayes' Theorem]
Let $A_1, ..., A_n$ be a partition of $\mathcal{S}$ and $B$ be an event. Then:

$$\Probcond{A_i}{B} = \frac{\Probcond{B}{A_i}\Prob{A_i}}{\sum_{j = 1}^n \Probcond{B}{A_j}\Prob{A_j}}$$
\end{theorem}

---

### Example 31

Roll a fair six-sided dice. Then, after observing the number of pips, roll another dice until more than that number of pips appears. What is the probability that the second die roll will show four pips?

\vspace{4in}

### Example 32

In a city Uber and Lyft transport passengers. 95% of drivers work for Uber, and 5% work for Lyft. One day there is a hit-and-run accident and a witness claims that she noticed the driver worked for Lyft. Lyft's defense attorneys subject her to testing, and in testing determine that she correctly identifies a car as belonging to Lyft 90% of the time but will claim a vehicle belongs to Lyft incorrectly 20% of the time. Based on this evidence, how likely is it that the driver who hit the pedestrian worked for Lyft?

\vspace{3in}

---

## Section 5: Independence

Two events $A$ and $B$ are **independent** if $\Probcond{A}{B} = \Prob{A}$. In some sense, information about the event $B$ gives no information about whether $A$ happened.

Use this to compute $\Probcond{B}{A}$.

\vspace{2in}

Use this to compute $\Probcond{A'}{B}$.

\vspace{2in}

A consequence of this defition of independence:^[In fact, this may be a more common definition of independence.]

\vspace{0.5in}

Below is a graphical representation of independence:^[Notice that independence is *not* the same as being disjoint. In fact, two disjoint events are not independent except in the most trivial cases. (That is, $\mathcal{S}$ and $\varnothing$ are technically independent.)]

\vspace{2in}

---

### Example 33

Consider rolling a 6-sided dice. Show that the events $A = \{\text{Number does not exceed 4}\}$ and $B = \{\text{Number is even}\}$ are independent.

\vspace{2in}

---

Suppose we have events $A_1, ..., A_n$. These events are **mutually independent** if, for $k \leq n$:

$$\Prob{A_{i_1} \cap A_{i_2} \cap ... \cap A_{i_k}} = \Prob{\bigcap_{j = 1}^k A_{i_j}} = \prod_{j = 1}^k \Prob{A_{i_j}} = \Prob{A_{i_1}} \Prob{A_{i_2}} ... \Prob{A_{i_k}}$$

This definition cannot be simplified to $\Prob{A_1 \cap ... \cap A_n} = \Prob{A_1} ... \Prob{A_n}$, as demonstrated below.^[This example was written by @george04 and is available here: http://www.engr.mun.ca/~ggeorge/MathGaz04.pdf]

---

### Example 34

Using the diagram below for finding probabilities, compute $\Prob{A \cap B \cap C}$ and $\Prob{A}\Prob{B}\Prob{C}$. Are $A$, $B$, and $C$ mutually independent?

\begin{center}
\begin{venndiagram3sets}[
labelOnlyA={0},
labelOnlyB={.10},
labelOnlyC={.16},
labelOnlyAB={.06},
labelOnlyAC={.10},
labelOnlyBC={.20},
labelABC={.04},
labelNotABC={.34},
tikzoptions={scale=1}]
\end{venndiagram3sets}
\end{center}

\vspace{6in}

### Example 35

We flip eight fair coins. What is the probability of $H$? $TH$? $TTH$? $TTTH$? In general, what is the probability for a sequence of $n$ flips to have $n - 1$ $T$ and a $H$ at the end?

\vspace{2in}

### Example 36

Below is a system of components. A signal will be sent from one end of the system, and will be successfully transmitted to the other end if no intermediate components fail. Each component functions independently of the others. What is the probability a transmission is sent successfully?

\vspace{6in}

### Example 36

Below is another system of components. A signal will be sent from one end of the system, and will be successfully transmitted to the other end if no intermediate components fail. Each component functions independently of the others. What is the probability a transmission is sent successfully?

\vspace{6in}
