--- 
title: |
  | MATH 3070
  | Lecture Notes
author: "Curtis Miller"
date: '2018-08-17'
output:
  bookdown::tufte_book2:
    includes:
      in_header: MATH3070NotesPreamble.sty
    number_sections: false
description: MATH 3070 Lecture Notes
documentclass: book
bibliography: "MATH3070Citations.bib"
biblio-style: apalike
---



# Preface

These lecture notes were written to accompany Jay Devore's *Probability and
Statistics for Engineering and the Sciences (9th ed.)* [@devore15]. They are
half-filled notes that students are expected to fill out as the instructor
lectures and fills out the notes himself on a projected screen for the students
to see. This is my preferred lecturing style, as it allows for definitions to be
present without needing to waste time writing them down by hand, example
problems to be written but not yet solved, and generally improves the flow of
the class. Additionally, R code accompanies the mathematical presentation so
that students can see how R integrates with the concepts they learn, something
that Devore's book does not do. As the class these notes were written for has an
accompanying R programming lab, this is a highly useful feature.

These notes do not stand alone and follow tightly to Prof. Devore's book, and I
will never release filled-out notes. Additionally, these notes are not intended
to be an introduction to R programming; other notes I have written serve that
purpose. The R code here is intended to be "real," written to solve problems
"the best way possible" rather than in a way students will immediately
understand. Devore's book, and some other resource for learning R programming
(such as the lab textbook for the course by @verzani14) *must* accompany these
notes for them to be of any use. That said, I believe they make a great
supplement to Devore's book.

These notes follow Devore's structure exactly and cover Chapters 1 through 9,
the chapters covered by the course. Comments are made in the margins,
representing asides that are useful or interesting to know (and might even be
test or quiz material) yet serve as asides to the main body of information. The
notes follow the famous Tufte style; this allows space for the comments and also
for plenty of whitespace for note taking and problem solving. There should be
plenty of room for students to write.

I hope you find these notes useful.

Curtis Miller
