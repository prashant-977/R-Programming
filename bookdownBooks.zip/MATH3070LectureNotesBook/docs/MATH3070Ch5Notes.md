---
title: 'Chapter 5: Joint Probability Distributions and Random Samples'
subtitle: "Textbook Notes"
author: "Curtis Miller"
date: "2018-08-17"
output:
  tufte::tufte_handout:
    citation_package: natbib
    latex_engine: pdflatex
    includes:
      in_header: MATH3070NotesPreamble.sty
  tufte::tufte_html: 
  tufte::tufte_book:
    citation_package: natbib
    latex_engine: pdflatex
bibliography: MATH3070Citations.bib
link-citations: yes
---



# Chapter 5: Joint Probability Distributions and Random Samples

## Introduction

\newthought{We may naturally inquire} about collections of random variables that are related to each other in some way. For instance, we may record an individual's height and weight, calling these random variables $X$ and $Y$, and ask if these are correlated, uncorrelated, or even independent characteristics, and describe a probability model that accounts for the relationship in these two characteristics.

Additionally, we may have a large collection of random variables, say $X_1, X_2, \ldots, X_n$ which will be used to estimate some essential quantity of a distribution, such as the mean $\mu$. We compute some quantity based on this collection of random variables, such as $\bar{X} = \frac{1}{n}\sum_{i = 1}^n X_i$, or any other $T = T(X_1, \ldots, X_n)$. This quantity, dependent on random variables, is itself a random variable, and we call it a statistic. Being a statistic it has its own probability distribution, with its own mean and variance and cdf, and we can use the distribution of the statistic to make statements about the process that generated the original dataset $X_1, \ldots, X_n$. It is here when probability theory begins to turn into statistical theory.

## Section 1: Jointly Distributed Random Variables

Suppose $X$ and $Y$ are two discrete random variables. Their **joint probability mass function** is described below:

\vspace{0.5in}

This can be used to compute $\Prob{(X,Y) \in A}$ for an event $A$:

\vspace{0.5in}

From this we can compute the **marginal probability mass functions**, $p_X(x)$ and $p_Y(y)$, for $X$ and $Y$ respectively.

\vspace{1in}

These represent the probability distribution of $X$ and $Y$ respectively regardless of what value the other rv takes.

We can also compute what is known as the **conditional probability mass function of $Y$ given $X = x$**, which represents the probability distribution of $Y$ when we know that $X = x$. The  **conditional probability mass function of $X$ given $Y = y$** is defined in a similar manner.

\vspace{1.5in}

---

### Example 1

A fair six-sided die is rolled; let $X$ represent the number of pips shown. At the same time, a fair coin is flipped, and $Y(\omega) = 1$ if the coin lands heads-up, and $Y(\omega) = 2$ if the coin lands tails-up. The joint pmf of $X$ and $Y$ is

\vspace{1in}

1. Compute $\Prob{X < Y}$.

\vspace{2in}

2. Compute $\Prob{\text{Both } X \text{ and } Y \text{are even}}$

\vspace{2in}

3. Find the marginal pmfs for both $X$ and $Y$.

\vspace{4in}

4. Find the conditional distributions $p_{X|Y}(x|y)$ and $p_{Y|X}(y|x)$.

\newpage


```r
library(discreteRV)
```

```
## 
## Attaching package: 'discreteRV'
```

```
## The following object is masked from 'package:base':
## 
##     %in%
```

```r
library(magrittr)  # Adds the %>% operator

XY <- jointRV(list(1:6, 1:2), probs = rep(1/12, times = 12))
(X <- marginal(XY, 1))  # The relationship between X and Y is still preserved
```

```
## Random variable with 6 outcomes
## 
## Outcomes   1   2   3   4   5   6
## Probs    1/6 1/6 1/6 1/6 1/6 1/6
```

```r
(Y <- marginal(XY, 2))
```

```
## Random variable with 2 outcomes
## 
## Outcomes   1   2
## Probs    1/2 1/2
```

```r
joint(X, Y)
```

```
## Random variable with 12 outcomes
## 
## Outcomes  1,1  1,2  2,1  2,2  3,1  3,2  4,1  4,2  5,1  5,2  6,1  6,2
## Probs    1/12 1/12 1/12 1/12 1/12 1/12 1/12 1/12 1/12 1/12 1/12 1/12
```

```r
P(X < Y)
```

```
## [1] 0.08333333
```

```r
P((X %in% c(2, 4, 6)) %AND% (Y %in% c(2)))  # Both even
```

```
## [1] 0.25
```

```r
X | Y == 2  # Gets a conditional random variable
```

```
## Random variable with 6 outcomes
## 
## Outcomes   1   2   3   4   5   6
## Probs    1/6 1/6 1/6 1/6 1/6 1/6
```

```r
YgivenX <- function(x) {Y | X == x}
XgivenY <- function(y) {X | Y == y}

YgivenX(2)
```

```
## Random variable with 2 outcomes
## 
## Outcomes   1   2
## Probs    1/2 1/2
```

```r
XgivenY(2)
```

```
## Random variable with 6 outcomes
## 
## Outcomes   1   2   3   4   5   6
## Probs    1/6 1/6 1/6 1/6 1/6 1/6
```

---

Now suppose that $X$ and $Y$ are continuous random variables. Much is the same; we work with a **joint probability density function**, **marginal probability density functions**, and **conditional probability density functions**.

\vspace{4in}

---

### Example 2

A company sells bags of "deluxe" mixed nuts, containing almonds, cashews, and peanuts. One bag is five pounds, and the joint pdf for the amount of almonds $X$ and cashews $Y$ in the bag (in pounds) is given below:

\vspace{1in}

(We don't need to worry about the amount of peanuts; this is simply $5 - X - Y$ and thus is completely determined given $X$ and $Y$.)

The region on which the pdf is illustrated below:

\vspace{1in}

1. Customers buying bags of "deluxe" mixed nuts complain when 60% of the nuts in the bag are peanuts. Compute the probability this occurs.

\vspace{6in}

2. Find the marginal distributions of $X$ and $Y$. Use this to compute $\E{X}$, $\E{Y}$, $\Var{X}$, and $\Var{Y}$.

\vspace{6in}

3. Find the conditional pdfs $f_{X|Y}(x|y)$ and $f_{Y|X}(y|x)$. Use this to compute $\Probcond{X > 2}{Y = 2}$.

\vspace{4in}

---

We say that two random variables $X$ and $Y$ are **independent** if

\vspace{2in}

---

### Example 3

Are the random variables in the previous two example independent? Explain why or why not.

\newpage


```r
independent(X, Y)  # For Example 1
```

```
## [1] TRUE
```

---

We can generalize our definitions from two to $n$ rvs, $X_1, \ldots, X_n$.

\vspace{4in}

We say that $X_1, \ldots, X_n$ are independent if for *every* subset $X_{i_1}, \ldots, X_{i_k}$ of the collection, we have

\vspace{1in}

If $X_1, \ldots, X_n$ are independent and each has the same pmf/pdf that $X_1, \ldots, X_n$ are **independent and identically distributed**, often abbreviated *i.i.d.*.^[This is a typical assumption about a dataset in statistics.]

---

### Example 4

Compute $\Prob{\min\{X_1, ..., X_n\} \geq x}$ if $X_1, \ldots, X_n$ are *i.i.d.*.

\vspace{3in}

---

We can generalize the binomial distribution we saw before the the **multinomial distribution**. We have $r$ categories, and a single observation belongs to category $i$ with probability $p_i$. We count how many observations belong to category $i$; this gives $X_i$. Then the vector $(X_1, \ldots, X_r)$ follows the multinomial distribution, or $(X_1, \ldots, X_r) \sim \operatorname{MULTINOM}(p_1, \ldots, p_r)$^[The binomial distribution is a particular instance of the multinomial distribution, when $r = 2$. We omit the count of tails, which we may call $X_2$, as it's redundant information given $X_1$.], and we have the pmf

\vspace{2in}

## Section 2: Expected Values, Covariance, and Correlation

Expectations involving two random variables are defined similarly to the univariate cases.

\vspace{2in}

---

### Example 5

Reconsider the random variables in Examples 1 and 2. Compute $\E{XY}$ for both cases.

\newpage

\vfill

\phantom{blablabla}

\newpage


```r
E(X * Y)  # For Example 1's random variables
```

```
## [1] 5.25
```

---

One measure of the relationship between two random variables is the **covariance**.

\vspace{1in}

The covariance is positive if the two random variables tend to be large together, while the covariance is negative if one rv tends to be large when the other tends to be small. If $\Cov{X}{Y} = 0$, then $X$ and $Y$ are **uncorrelated**.^[Due to the relationship between the covariance and the variance, we sometimes see the notation $\Cov{X}{Y} = \sigma_{XY}$.]

We also have the following shortcut formula for the covariance:

\vspace{0.5in}

It's obtained in a similar manner to shortcut formulas found for computing $\Var{X}$.^[From this it's clear that $\Cov{X}{X} = \Var{X}$.]

Notice that the covariance is *not* insensitive to the units of the random variable; in fact, we can compute the covariance $\Cov{aX + b}{cY + d}$:

\vspace{0.5in}

Changing the units changes the covariance. A unit-free measure of the relationship between $X$ and $Y$ is the **correlation**.^[The usual Greek letter representing correlation is $\rho$.]

\vspace{0.5in}

The correlation is 1 if there is a perfect positive *linear* relationship between $X$ and $Y$, -1 if there is a perfect negative *linear* relationship, and 0 if there is no *linear* relationship between $X$ and $Y$.^[Notice the emphasis on the word "linear"; there can be a relationship between $X$ and $Y$ that would make their correlation small yet there could still be a strong nonlinear relationship linking the two variables.] Thus $\abs{\rho}$ determines the *strength* of the relationship^[We can classify the strength of the relationship between rvs using completely arbitrary cutoffs; specifically, we could say that if $\abs{\rho} < 0.3$ there is no notable correlation, if $\abs{\rho} > 0.7$ there is a strong correlation, and otherwise the correlation is weak.] between $X$ and $Y$ and $\operatorname{sign}(\rho)$ determines the *direction* of the relationship.^[There is a sample statistic for estimating $\rho$ from paired data $(x_1, y_i)$: $$r = \frac{1}{s_x s_y (n - 1)}\sum_{i = 1}^n (x_i - \bar{x})(y_i - \bar{y})$$ The interpretation is the same. We do not discuss the sample statistic in this course.]

---

### Example 6

Compute the covariance and correlation for the random variables mentioned in Examples 1 and 2.

\newpage


```r
## For Example 1
(sigma_xy <- E(X * Y) - E(X) * E(Y))
```

```
## [1] 0
```

---

If $X$ and $Y$ are independent, then $\Cov{X}{Y} = 0$.^[As a consequence, we can equivalently say that $\E{XY} = \E{X}\E{Y}$ when $X$ and $Y$ are idependent.] The converse is *not* true in general, as the following example shows.

### Example 7

The point $(U, V)$ is equally likely to be any of the points in the sample space $\mathcal{S} = \{(1, 1), (1, -1), (-1, 2), (-1, -2)\}$. Compute $\Cov{U}{V}$. Are $U$ and $V$ independent?

\newpage

---


```r
(UV <- jointRV(list(c(-1, 1), c(-2, -1, 1, 2)),
               probs = c(1/4, 0, 0, 1/4, 0, 1/4, 1/4, 0)))
```

```
## Random variable with 4 outcomes
## 
## Outcomes -1,-2  -1,2  1,-1   1,1
## Probs      1/4   1/4   1/4   1/4
```

```r
(U <- marginal(UV, 1))
```

```
## Random variable with 2 outcomes
## 
## Outcomes  -1   1
## Probs    1/2 1/2
```

```r
(V <- marginal(UV, 2))
```

```
## Random variable with 4 outcomes
## 
## Outcomes  -2  -1   1   2
## Probs    1/4 1/4 1/4 1/4
```

```r
E(U*V) - E(U) * E(V)
```

```
## [1] 0
```

```r
independent(U, V)
```

```
## [1] FALSE
```

---

We say $(X_1, X_2)$ follows the bivariate Normal distribution, or $(X_1, X_2) \sim \operatorname{BINORM}(\mu_1, \mu_2, \sigma_1, \sigma_2, \rho)$, if the joint pdf of $X_1$ and $X_2$ is

\vspace{1in}

The pdf of the bivariate Normal distribution is illustrated below.


```r
library(mvtnorm)
library(lattice)

my.settings <- list(superpose.polygon = list(border = "transparent"))
points <- data.frame("x" = rep(seq(-3, 3, length.out = 100), times = 100),
                     "y" = rep(seq(-3, 3, length.out = 100), each = 100))
points$z <- apply(points, 1, function(r) {dmvnorm(r)})
head(points)
```

```
##           x  y            z
## 1 -3.000000 -3 1.964128e-05
## 2 -2.939394 -3 2.351445e-05
## 3 -2.878788 -3 2.804818e-05
## 4 -2.818182 -3 3.333337e-05
## 5 -2.757576 -3 3.946923e-05
## 6 -2.696970 -3 4.656321e-05
```

```r
wireframe(z ~ x * y, data = points, lines = FALSE,
          col = "transparent", shade = TRUE)
```


\includegraphics{MATH3070Ch5Notes_files/figure-latex/unnamed-chunk-6-1} 

```r
contourplot(z ~ x * y, data = points)
```


\includegraphics{MATH3070Ch5Notes_files/figure-latex/unnamed-chunk-6-2} 

```r
levelplot(z ~ x * y, data = points, drape = TRUE,
          col.regions = terrain.colors(100))
```


\includegraphics{MATH3070Ch5Notes_files/figure-latex/unnamed-chunk-6-3} 

\newpage

If you were to slice the pdf in any direction, the resulting plot would be another Normal distribution. Specifically, the marginal distributions $f_{X_1}(x_1)$ and $f_{X_2}(x_2)$ are Normal distributions, and conditional distributions $f_{X_1|X_2}(x_1 | x_2)$ and $f_{X_2|X_1}(x_2 | x_1)$ are all all Normal distributions.

\vspace{3in}

We have $\E{X_1} = \mu_1$, $\E{X_2} = \mu_2$, $\SD{X_1} = \sigma_1$, $\SD{X_2} = \sigma_2$, and $\Corr{X_1}{X_2} = \rho$. Crucially, when $(X_1, X_2)$ follows a bivariate Normal distribution, $\Cov{X_1}{X_2}$ *does* imply independence!^[This is not the same as saying that if two random variables are Normally distributed and uncorrelated they are independent. Joint normality does not follow from the normality of the marginal distributions; for example, if we choose $Z_1 \sim N(0,1)$ and $Z_2 = SZ_1$ with $\Prob{S = 1} = \Prob{S = -1} = \frac{1}{2}$, then $Z_2 \sim N(0,1)$, and the marginal distributions of $(Z_1, Z_2)$ are thus standard Normal distributions, and $\Cov{Z_1}{Z_2} = 0$. However, $Z_1$ and $Z_2$ are obviously *not* independent since if we know $Z_1$ then we know $Z_2$ differs from $Z_1$ by at most a sign.]

---

### Example 8

Let $H_C$ represent the height of a son and $H_F$ the height of the son's father (in inches). Suppose

$$(H_C, H_F) \sim \operatorname{BINORM}(69.2, 69.2, 2.6, 2.6, 0.4)$$

1. What are the marginal distributions of $H_C$ and $H_F$?

\vspace{2in}

2. Suppose a person's father is 78 inches tall. Find an equal-tailed^[In general, when we say an interval is equal-tailed, we mean that the probability that the random variable is too small to be in the region is equal to the probability that the random variable is too large. We need this restriction in order to have a unique solution; otherwise, there could be an infinite number of solutions.] interval such that the probability the child's height is in this interval is 0.95.

\newpage


```r
## Marginal distributions are trivial; let's worry about the conditional
mu1 <- 69.2; mu2 <- 69.2; sigma1 <- 2.6; sigma2 <- 2.6; rho <- 0.4
h <- 78
(mu_2g1 <- (mu1 - rho * mu2 * sigma1 / sigma2) + rho * sigma1 * h / sigma2)
```

```
## [1] 72.72
```

```r
(sigma_2g1 <- sqrt((1 - rho^2) * sigma1^2))
```

```
## [1] 2.382939
```

```r
qnorm(0.025, mean = mu_2g1, sd = sigma_2g1)  # Lower bound
```

```
## [1] 68.04952
```

```r
qnorm(0.975, mean = mu_2g1, sd = sigma_2g1)  # Upper bound
```

```
## [1] 77.39048
```

---

## Section 5: The Distribution of a Linear Combination^[In my opinion, Section 5 of this chapter is a more logical successor of Section 2; we will come back to Section 3 later.]

Consider a collection of $n$ random variables $X_1, \ldots, X_n$ and numerical constants $a_1, \ldots, a_n$. The rv $Y$ is a **linear combination** of the random variables $X_1, \ldots, X_n$ if $Y$ is of the form

\vspace{0.5in}

\begin{proposition}
Suppose $\E{X_i} = \mu_i$ and $\Var{X_i} = \sigma_i^2$. The following facts are true:

\vspace{3in}
\end{proposition}

Thus we have the important property about expectations; they are linear operators, to use linear algebra language. The variance is not a linear operator (although it is a sublinear operator), but the covariance is a bilinear operator (linear in both its arguments).

\begin{corollary}
Suppose $X_1$ and $X_2$ are two independent random variables. Then:

\vspace{2in}
\end{corollary}

We can weaken the independence assumption to simply being uncorrelated and the variance computation will still be true.

\begin{proposition}
Suppose $X_1$ and $X_2$ are two Normal random variables. Then
\vspace{0.5in}
\end{proposition}

\begin{corollary}
A linear combination of Normal random variables also follows a Normal distribution.
\end{corollary}

---

### Example 9

Suppose $X_1, \ldots, X_n$ are i.i.d. random variables. Compute the expected value, variance, and standard deviation of $\bar{X} = \frac{1}{n}\sum_{i = 1}^n X_i$.

\vspace{3in}

### Example 10

Suppose $X_1, \ldots, X_n$ are i.i.d. random variables. Compute the expected value, variance, and standard deviation of $T = \sum_{i = 1}^n X_i$

There are several random variables where we know the distribution of sums of those random variables. Below is a summary:

\vspace{4in}

---

## Section 3: Statistics and Their Distributions

We will call the collection $X_1, \ldots, X_n$ a **random sample** if it consists of i.i.d. random variables. We will call any quantity we can compute from a random sample a **statistic**. Before the dataset is observed, a statistic is a random quantity, with its own distribution, referred to as the **sampling distribution**; statistics in this random state are usually referred to using upper-case letters, while the observed statistic (after we have a dataset) is usually referred to using lower-case letters.

Examples of statistics include:

\vspace{1in}

---

### Example 11

Let $X_1, \ldots, X_n$ be i.i.d.r.v. with $X_1 \sim \operatorname{Ber}(p)$. What is the sampling distribution of $\bar{X}$?

\vspace{4in}

### Example 12

Let $X_1, \ldots, X_n$ be i.i.d.r.v. with $X_1 \sim N(\mu, \sigma)$. What is the sampling distribution of $\bar{X}$? Use the sampling distribution to find an interval such that $\Prob{l(\bar{X}) \leq \mu \leq u(\bar{X})} = 1 - \alpha$.

\vspace{4in}

---

One approach to finding information about the sampling distribution of statistics is to use **simulations**. We generate $K$ random samples of size $n$, $X_{1,k}, \ldots, X_{n,k}$, $k \in [K]$. For each sample we compute the statistic of interest $T(X_{1,k}, \ldots, X_{n,k}) = T_k$, and then study the random sample $T_1, \ldots, T_K$.

---

### Example 13

For the Normal distribution, we could estimate the parameter $\mu$ using either the sample mean $\bar{X}$ or the sample median $\tilde{X}$. What are the properties of these two statistics' sampling distributions? What are their respective shapes? Which has a smaller variance?

Let's suppose $X_{1} \sim N(0, 1)$, then conduct a simulation study to compare these statistics. We'll look at $n = 10$ and use $K = 1000$ samples.


```r
## Generate 1000 random samples of size ten, storing them in a 10x1000 matrix
datamat <- replicate(1000, rnorm(10))
sim_mean <- apply(datamat, 2, mean)
sim_med <- apply(datamat, 2, median)
boxplot(sim_mean, sim_med)
```


\includegraphics{MATH3070Ch5Notes_files/figure-latex/unnamed-chunk-8-1} 

```r
summary(sim_mean)
```

```
##      Min.   1st Qu.    Median      Mean 
## -1.039457 -0.212232 -0.011803 -0.002945 
##   3rd Qu.      Max. 
##  0.212163  1.003501
```

```r
summary(sim_med)
```

```
##       Min.    1st Qu.     Median       Mean 
## -1.2255786 -0.2481265 -0.0157162  0.0009959 
##    3rd Qu.       Max. 
##  0.2474923  1.0624186
```

```r
var(sim_mean)
```

```
## [1] 0.1019921
```

```r
var(sim_med)
```

```
## [1] 0.1377739
```

```r
qqnorm(sim_mean); qqline(sim_mean)
```


\includegraphics{MATH3070Ch5Notes_files/figure-latex/unnamed-chunk-8-2} 

```r
qqnorm(sim_med); qqline(sim_med)
```


\includegraphics{MATH3070Ch5Notes_files/figure-latex/unnamed-chunk-8-3} 

### Example 14

Let's now consider the sample mean of random samples $U_1, \ldots, U_n$ with $U_1 \sim \operatorname{UNIF}(0, 1)$. What can we say about the distribution of the sample mean $\bar{U}$ as the sample size $n$ gets large?

We will create 1000 samples for $n \in \{5, 20, 80\}$, then compare the distributions.


```r
sizes <- c(2, 5, 20, 80)
k <- 1000

datasets <- lapply(sizes, function(n) {
  replicate(k, runif(n))
})
names(datasets) <- sizes
str(datasets)
```

```
## List of 4
##  $ 2 : num [1:2, 1:1000] 0.7295 0.7723 0.0748 0.556 0.0579 ...
##  $ 5 : num [1:5, 1:1000] 0.6213 0.3327 0.1839 0.196 0.0526 ...
##  $ 20: num [1:20, 1:1000] 0.737 0.513 0.62 0.535 0.538 ...
##  $ 80: num [1:80, 1:1000] 0.25622 0.00523 0.5223 0.40644 0.21757 ...
```

```r
sim_mean_unif <- lapply(datasets, function(d) {apply(d, 2, mean)})
str(sim_mean_unif)
```

```
## List of 4
##  $ 2 : num [1:1000] 0.751 0.315 0.31 0.675 0.439 ...
##  $ 5 : num [1:1000] 0.277 0.483 0.347 0.596 0.398 ...
##  $ 20: num [1:1000] 0.499 0.477 0.435 0.497 0.516 ...
##  $ 80: num [1:1000] 0.47 0.515 0.511 0.45 0.576 ...
```

```r
for (x in sim_mean_unif) {
  print(summary(x))
  hist(x, freq = FALSE)
  lines(seq(0, 1, length.out = 1000),
        dnorm(seq(0, 1, length.out = 1000), mean = mean(x), sd = sd(x)))
  qqnorm(x); qqline(x)
}
```

```
##    Min. 1st Qu.  Median    Mean 3rd Qu. 
## 0.02094 0.34923 0.50265 0.49717 0.65324 
##    Max. 
## 0.97487
```


\includegraphics{MATH3070Ch5Notes_files/figure-latex/unnamed-chunk-9-1} 
\includegraphics{MATH3070Ch5Notes_files/figure-latex/unnamed-chunk-9-2} 

```
##    Min. 1st Qu.  Median    Mean 3rd Qu. 
##  0.1602  0.4063  0.5032  0.5000  0.5928 
##    Max. 
##  0.8897
```


\includegraphics{MATH3070Ch5Notes_files/figure-latex/unnamed-chunk-9-3} 
\includegraphics{MATH3070Ch5Notes_files/figure-latex/unnamed-chunk-9-4} 

```
##    Min. 1st Qu.  Median    Mean 3rd Qu. 
##  0.2991  0.4555  0.4985  0.4977  0.5418 
##    Max. 
##  0.6859
```


\includegraphics{MATH3070Ch5Notes_files/figure-latex/unnamed-chunk-9-5} 
\includegraphics{MATH3070Ch5Notes_files/figure-latex/unnamed-chunk-9-6} 

```
##    Min. 1st Qu.  Median    Mean 3rd Qu. 
##  0.4005  0.4784  0.4981  0.4998  0.5203 
##    Max. 
##  0.5955
```


\includegraphics{MATH3070Ch5Notes_files/figure-latex/unnamed-chunk-9-7} 
\includegraphics{MATH3070Ch5Notes_files/figure-latex/unnamed-chunk-9-8} 

---

## Section 4: The Distribution of the Sample Mean

There are two theorems that form the cornerstone of probability and statistics: the law of large numbers and the central limit theorem. The Law of Large Numbers (LLN) guarantees us that the sample mean will approximately equal the population mean, while the Central Limit Theorem (CLT) describes the distribution of the sample mean for large $n$ when we have a mean and a variance.

\begin{theorem}[Law of Large Numbers]
Let $X_1, X_2, \ldots$ be a sequence of of i.i.d.r.v. with $\E{X_1} = \mu$, and let $\bar{X}_n = \frac{1}{n}\sum_{i = 1}^n X_i$. Then the probability the (random) sequence $\bar{X}_n$ converges to $\mu$ is 1.
\end{theorem}

\begin{theorem}[Central Limit Theorem]
Under the same assumptions as the Law of Large Numbers but with the additional assumption that $\Var{X_1} = \sigma^2$, $\Prob{\frac{\bar{X}_n - \mu}{\sigma/\sqrt{n}} \leq z} \to \Phi(z)$ for all $z$. In other words, the distribution of $\bar{X}_n$ is approximately $N\left(\mu, \frac{\sigma}{\sqrt{n}}\right)$, with the approximation improving as $n \to \infty$.
\end{theorem}

More directly, the CLT describes the behavior of sums of i.i.d.r.v. as more random variables are summed. The CLT explains why some distributions--like the binomial distribution, the Poisson distribution, the gamma distribution, and the $\chi^2$-distribution--can be approximated with the Normal distribution as one of their parameters grows large; these distributions can be interpreted as the distributions of sums of i.i.d.r.v.^[Specifically: $\operatorname{BIN}(n,p)$ is the sum of $n$ $\operatorname{Ber}(p)$ r.v.s; $\operatorname{POI}(n)$ is the sum of $n$ $\operatorname{POI}(1)$ r.v.s; $\operatorname{GAMMA}(\alpha, n)$ is the sum of $n$ $\operatorname{EXP}(\alpha)$ r.v.s; and $\chi^2(n)$ is the sum of $n$ $\chi^2(1)$ r.v.s.] and thus the CLT applies.^[The CLT requires that $\Var{X_1} < \infty$; if this does not hold, the CLT no longer applies and its conclusion may not even be true.]

Thanks to the CLT, we can describe the distribution of the sample mean without worrying about the exact distribution of the underlying data if the sample size $n$ is large enouch^[In general it's safe to use the CLT if $n > 30$.], since the CLT says that the initial distribution is eventually "forgotten" by the sample mean.

---

### Example 15

The average customer visiting a grocery store spends $X$ dollars, where $\E{X} = 50$ and $\SD{X} = 55$.^[Notice $X$ is non-negative but $\SD{X} > \E{X}$. This can happen with skewed distributions.] Every month about 30,000 purchases are made at the grocery store.

1. What will be the (approximate) distribution of the average purchase, $\bar{X}$?

\vspace{2in}

2. What is the (approximate) probability that the revenue of the grocery store in a month is less than \$1,485,000

\newpage


```r
55/sqrt(30000)  # sd of xbar
```

```
## [1] 0.3175426
```

```r
pnorm(1485000, mean = 50 * 30000, sd = 55 * sqrt(30000))
```

```
## [1] 0.05767537
```

---
