--- 
title: "MATH 3070 Summer R Lecture Notes"
author: "Curtis Miller"
date: '2018-08-17'
output:
  bookdown::pdf_book:
    includes:
      in_header: preamble.tex
    number_sections: false
  bookdown::gitbook:
    number_sections: false
description: MATH 3070 Summer Lecture Notes
documentclass: book
---

# Preface {-}

These lecture notes were written by me to accompany John Verzani's [*Using R  for Introductory Statistics (2nd ed.)*](https://www.crcpress.com/Using-R-for-Introductory-Statistics-Second-Edition/Verzani/p/book/9781466590731), to be delivered in lectures teaching students how to program with R in the programming lab accompanying a lecture section focusing on the statistical methods themselves. No knowledge of programming is assumed; my objective was to teach basic R programming well enough to use R for statistical analyses.

These notes are not intended to stand alone; I like Verzani's book and I believe that these notes should supplement it, not replace it. For those taking the programming lab for the University of Utah's Mathematics Department statistics courses, I would *insist* on reading Verzani's book in addition to these lecture notes. However, these notes could serve as a light weight introduction to R and statistical programming.

These lecture notes were used for an eight-week intensive course on statistics, with the lab covering R programming. The first two lectures focus almost exclusively on R programming. After this, lectures focus more on statistical topics. The third lecture discusses R for probability; the fourth, visualization; the fifth, a light introduction to multivariate analysis (a more complete discussion is meant for a later course); finally, the last lectures cover inferential statistics and confidence intervals, starting with computationally intensive methods (Lecture 6) and then showing how the analytical methods are implemented in R (Lectures 7 & 8).

These were the first lecture notes I wrote for the R programming lab. I normally do not teach eight-week courses, so I had to adapt these lecture notes to a different schedule. Not only that, while I taught both the lecture and lab portions of the class in the intensive summer classes (and thus knew exactly what was covered in the lecture session), I had to adjust my lectures to account for the speed of the lecture section instructors during regular semesters. Thus, another version of these notes exists for a fourteen-week schedule, and they include more material inserted to account for the difference in pace between the lab and lecture sections. Perhaps consider checking out that collection of lecture notes as well.

In any case, I hope that you find these notes useful, and wish you the best of luck.

Curtis Miller
